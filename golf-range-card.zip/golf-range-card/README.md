# Golf Range Card

Phone-first training card with a print-ready A4 PDF built from the same source.
Push to `main` → GitHub Actions renders the PDF and publishes both to GitHub Pages.

Current revision: **Rev. 5** — driver launch conditions and speed training (12-week
block, leading the card), then posture retention, ball transfer and low point
confirmation.

## Layout

```
src/index.html            Phone page (PWA, offline, tick-off drills, saved scorecard)
src/print.html            A4 print source — the PDF is rendered from this
src/manifest.webmanifest  Home-screen install metadata
src/sw.js                 Service worker; __BUILD__ is stamped by the workflow
src/icon-192.png          Icons
src/icon-512.png
.github/workflows/build.yml
```

Nothing is generated into the repo. The workflow assembles `_site/` and hands it
straight to Pages, so there is no build output to commit or keep in sync.

## First-time setup

```bash
cd golf-range-card
git init -b main

# This repo only — keeps it separate from any work identity on this machine.
git config user.name  "Tommi Riipinen"
git config user.email "tommi.riipinen@gmail.com"

git add .
git commit -m "Range card rev. 5"
```

Then create an empty repo under your personal account (the one on
`tommi.riipinen@gmail.com`) — **do not** let GitHub add a README or license,
or the first push will be rejected:

```bash
git remote add origin git@github.com:<your-username>/golf-range-card.git
git push -u origin main
```

Finally, in the repo: **Settings → Pages → Build and deployment → Source:
GitHub Actions**. Not "Deploy from a branch" — the workflow uses the Pages
artifact API and will fail against the branch source. The first push after
switching this publishes the site.

If the account has SSO or you would rather use HTTPS, swap the remote for
`https://github.com/<your-username>/golf-range-card.git` and authenticate with a
personal access token.

### Public or private?

Pages on a **private** repo needs a paid plan. On the free plan, either make the
repo public (it is a golf practice card — nothing sensitive) or keep it private
and skip Pages, running `make` locally instead.

## URLs once deployed

```
https://<your-username>.github.io/golf-range-card/            phone page
https://<your-username>.github.io/golf-range-card/range-card.pdf   print PDF
```

Open the phone page in Safari → Share → **Add to Home Screen**. The service
worker caches the page, icons and PDF, so it works at the range with no signal.
It revalidates in the background whenever there is coverage, so a new revision
lands on the next launch after a push.

## Editing

Both files are self-contained — no build step, no dependencies, no framework.

- **Drills, ladder rungs, scorecard rows, traps** live in the `DRILLS`,
  `LADDER`, `SCORE` and `TRAPS` arrays near the bottom of `src/index.html`.
  Add or reorder entries there and the page rebuilds itself on load.
- **Print layout** is CSS at the top of `src/print.html`. Page breaks are
  explicit `<div class="pagebreak">` elements, and each page carries its own
  footer with a hardcoded page number — renumber them if you add a page. The
  card is eleven pages; `make` should produce exactly eleven, and if it produces
  more, a section has spilled and the numbering is wrong.
- **Print density** comes from `@media print { html { zoom: 0.72 } }` in
  `src/print.html`. That value is what makes one `pagebreak` section equal one
  A4 page under Chrome. Changing it re-paginates everything.
- Keep the two in step when you revise. The phone page is the operational
  subset; the PDF carries the full reasoning.

Ticked drills, the selected ladder rung and the scorecard are stored in
`localStorage` under the `grc.v5.` prefix. Bumping that prefix on a future
revision gives you a clean slate without clearing anything by hand.

## Local build

```bash
make          # renders build/range-card.pdf
make serve    # http://localhost:8000 — needed for the service worker,
              # which will not register from a file:// URL
```

Requires Google Chrome or Chromium — the PDF is rendered with `--headless=new
--print-to-pdf`. Override the binary with `make CHROME=/path/to/chrome` if it is
somewhere unusual. wkhtmltopdf was the original renderer; it is archived
upstream and no longer packaged by Homebrew or recent Ubuntu, so the Makefile
and the workflow both use Chrome now.

## Revising with Claude Code

```
Update src/print.html and src/index.html to rev. 6: <change>.
Keep the two consistent, renumber the print footers if the page count
changes, and bump the localStorage prefix in index.html if the scorecard
rows change.
```

Commit and push; the Action handles the rest.
