# Golf Range Card

Phone-first training card with a print-ready A4 PDF built from the same source.
Push to `main` → GitHub Actions renders the PDF and publishes both to GitHub Pages.

Current revision: **Rev. 4** — posture retention, ball transfer, low point confirmation, driver.

## Layout

```
src/index.html            Phone page (PWA, offline, tick-off drills, saved scorecard)
src/print.html            A4 print source — the PDF is rendered from this
src/manifest.webmanifest  Home-screen install metadata
src/sw.js                 Service worker; __BUILD__ is stamped by the workflow
src/icon-192.png          Icons
src/icon-512.png
.github/workflows/build.yml
```

Nothing is generated into the repo. The workflow assembles `_site/` and hands it
straight to Pages, so there is no build output to commit or keep in sync.

## First-time setup

```bash
cd golf-range-card
git init -b main

# This repo only — keeps it separate from any work identity on this machine.
git config user.name  "Tommi Riipinen"
git config user.email "tommi.riipinen@gmail.com"

git add .
git commit -m "Range card rev. 4"
```

Then create an empty repo under your personal account (the one on
`tommi.riipinen@gmail.com`) — **do not** let GitHub add a README or license,
or the first push will be rejected:

```bash
git remote add origin git@github.com:<your-username>/golf-range-card.git
git push -u origin main
```

Finally, in the repo: **Settings → Pages → Build and deployment → Source:
GitHub Actions**. Not "Deploy from a branch" — the workflow uses the Pages
artifact API and will fail against the branch source. The first push after
switching this publishes the site.

If the account has SSO or you would rather use HTTPS, swap the remote for
`https://github.com/<your-username>/golf-range-card.git` and authenticate with a
personal access token.

### Public or private?

Pages on a **private** repo needs a paid plan. On the free plan, either make the
repo public (it is a golf practice card — nothing sensitive) or keep it private
and skip Pages, running `make` locally instead.

## URLs once deployed

```
https://<your-username>.github.io/golf-range-card/            phone page
https://<your-username>.github.io/golf-range-card/range-card.pdf   print PDF
```

Open the phone page in Safari → Share → **Add to Home Screen**. The service
worker caches the page, icons and PDF, so it works at the range with no signal.
It revalidates in the background whenever there is coverage, so a new revision
lands on the next launch after a push.

## Editing

Both files are self-contained — no build step, no dependencies, no framework.

- **Drills, ladder rungs, scorecard rows, traps** live in the `DRILLS`,
  `LADDER`, `SCORE` and `TRAPS` arrays near the bottom of `src/index.html`.
  Add or reorder entries there and the page rebuilds itself on load.
- **Print layout** is CSS at the top of `src/print.html`. Page breaks are
  explicit `<div class="pagebreak">` elements, and each page carries its own
  footer with a hardcoded page number — renumber them if you add a page.
- Keep the two in step when you revise. The phone page is the operational
  subset; the PDF carries the full reasoning.

Ticked drills, the selected ladder rung and the scorecard are stored in
`localStorage` under the `grc.v4.` prefix. Bumping that prefix on a future
revision gives you a clean slate without clearing anything by hand.

## Local build

```bash
make          # renders build/range-card.pdf
make serve    # http://localhost:8000 — needed for the service worker,
              # which will not register from a file:// URL
```

Requires `wkhtmltopdf` (`brew install --cask wkhtmltopdf` on macOS). Note that
the Homebrew cask and the Ubuntu package are both the unpatched-Qt build, so
`--print-media-type` is unavailable; the stylesheets do not rely on it.

## Revising with Claude Code

```
Update src/print.html and src/index.html to rev. 5: <change>.
Keep the two consistent, renumber the print footers if the page count
changes, and bump the localStorage prefix in index.html if the scorecard
rows change.
```

Commit and push; the Action handles the rest.
